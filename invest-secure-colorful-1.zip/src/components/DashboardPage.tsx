import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { investmentPlans } from '../data/investmentPlans';
import { InvestmentCard } from './InvestmentCard';
import { DashboardStats } from './DashboardStats';
import { ActiveInvestments } from './ActiveInvestments';
import { DepositWithdraw } from './DepositWithdraw';
import { ReferralDashboard } from './ReferralDashboard';

export const DashboardPage: React.FC = () => {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'invest' | 'deposit' | 'referral'>('overview');
  const [investments, setInvestments] = useState<any[]>([]);

  const handleHire = (plan: any) => {
    if (user && user.balance >= plan.investment) {
      const newInvestment = {
        id: Date.now(),
        level: plan.level,
        amount: plan.investment,
        dailyReturn: plan.dailyReturn,
        daysRemaining: plan.duration,
        totalDays: plan.duration,
        carImage: plan.carImage,
        color: plan.color
      };
      setInvestments([...investments, newInvestment]);
      alert(`Successfully hired ${plan.level}! You will earn KSh ${plan.dailyReturn} daily for ${plan.duration} days.`);
    } else {
      alert('Insufficient balance. Please deposit funds first.');
    }
  };

  const totalDailyEarnings = investments.reduce((sum, inv) => sum + inv.dailyReturn, 0);
  const totalEarnings = investments.reduce((sum, inv) => sum + (inv.dailyReturn * (inv.totalDays - inv.daysRemaining)), 0);

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-md py-4 px-6 flex justify-between items-center">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
          Swapversend
        </h1>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <p className="text-sm text-gray-600">Balance</p>
            <p className="text-lg font-bold text-gray-800">KSh {user?.balance.toLocaleString()}</p>
          </div>
          <button onClick={logout} className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition">
            Logout
          </button>
        </div>
      </nav>

      <div className="flex border-b bg-white shadow-sm">
        {['overview', 'invest', 'deposit', 'referral'].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab as any)}
            className={`flex-1 py-4 font-semibold capitalize transition ${activeTab === tab ? 'border-b-4 border-purple-600 text-purple-600' : 'text-gray-600'}`}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {activeTab === 'overview' && (
          <>
            <DashboardStats
              activeInvestments={investments.length}
              dailyEarnings={totalDailyEarnings}
              totalEarnings={totalEarnings}
              referralEarnings={0}
            />
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Active Investments</h2>
            <ActiveInvestments investments={investments} />
          </>
        )}
        {activeTab === 'invest' && (
          <>
            <h2 className="text-3xl font-bold text-gray-800 mb-8">Investment Plans</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {investmentPlans.map((plan) => (
                <InvestmentCard key={plan.id} plan={plan} onHire={handleHire} />
              ))}
            </div>
          </>
        )}
        {activeTab === 'deposit' && <DepositWithdraw />}
        {activeTab === 'referral' && <ReferralDashboard />}
      </div>
    </div>
  );
};
