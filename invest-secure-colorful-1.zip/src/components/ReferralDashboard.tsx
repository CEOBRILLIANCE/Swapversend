import React from 'react';
import { useAuth } from '../contexts/AuthContext';

export const ReferralDashboard: React.FC = () => {
  const { user } = useAuth();
  const referralLink = `https://swapversend.com/ref/${user?.referralCode}`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(referralLink);
    alert('Referral link copied to clipboard!');
  };

  return (
    <div className="bg-gradient-to-br from-purple-600 to-blue-600 rounded-2xl shadow-xl p-8 text-white">
      <h2 className="text-3xl font-bold mb-6">Referral Program</h2>
      
      <div className="grid md:grid-cols-2 gap-6 mb-6">
        <div className="bg-white bg-opacity-20 backdrop-blur-lg rounded-xl p-6">
          <p className="text-sm opacity-90 mb-2">Level 1 Commission</p>
          <p className="text-4xl font-bold">20%</p>
        </div>
        <div className="bg-white bg-opacity-20 backdrop-blur-lg rounded-xl p-6">
          <p className="text-sm opacity-90 mb-2">Level 2 Commission</p>
          <p className="text-4xl font-bold">3%</p>
        </div>
      </div>

      <div className="bg-white bg-opacity-20 backdrop-blur-lg rounded-xl p-6">
        <p className="text-sm opacity-90 mb-2">Your Referral Code</p>
        <p className="text-2xl font-bold mb-4">{user?.referralCode}</p>
        <div className="flex gap-3">
          <input
            type="text"
            value={referralLink}
            readOnly
            className="flex-1 p-3 rounded-lg text-gray-800 font-mono text-sm"
          />
          <button
            onClick={copyToClipboard}
            className="bg-white text-purple-600 px-6 py-3 rounded-lg font-semibold hover:shadow-lg transition"
          >
            Copy
          </button>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-3 gap-4">
        <div className="text-center">
          <p className="text-3xl font-bold">0</p>
          <p className="text-sm opacity-90">Total Referrals</p>
        </div>
        <div className="text-center">
          <p className="text-3xl font-bold">KSh 0</p>
          <p className="text-sm opacity-90">Level 1 Earnings</p>
        </div>
        <div className="text-center">
          <p className="text-3xl font-bold">KSh 0</p>
          <p className="text-sm opacity-90">Level 2 Earnings</p>
        </div>
      </div>
    </div>
  );
};
