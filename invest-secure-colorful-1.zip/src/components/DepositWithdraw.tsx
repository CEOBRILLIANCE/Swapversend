import React, { useState } from 'react';

export const DepositWithdraw: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'deposit' | 'withdraw'>('deposit');
  const [amount, setAmount] = useState('');
  const [bankDetails, setBankDetails] = useState('');

  const handleDeposit = () => {
    window.open('https://eversend.me/profitable', '_blank');
  };

  const handleWithdraw = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Withdrawal request for KSh ${amount} submitted successfully! Processing time: 24-48 hours.`);
    setAmount('');
    setBankDetails('');
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-6">
      <div className="flex border-b mb-6">
        <button
          onClick={() => setActiveTab('deposit')}
          className={`flex-1 py-3 font-semibold transition ${activeTab === 'deposit' ? 'border-b-4 border-green-600 text-green-600' : 'text-gray-500'}`}
        >
          Deposit
        </button>
        <button
          onClick={() => setActiveTab('withdraw')}
          className={`flex-1 py-3 font-semibold transition ${activeTab === 'withdraw' ? 'border-b-4 border-purple-600 text-purple-600' : 'text-gray-500'}`}
        >
          Withdraw
        </button>
      </div>

      {activeTab === 'deposit' ? (
        <div className="text-center">
          <p className="text-gray-600 mb-6">Click below to deposit funds via Eversend</p>
          <button
            onClick={handleDeposit}
            className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-8 py-4 rounded-lg font-semibold hover:shadow-lg transition"
          >
            Deposit via Eversend
          </button>
        </div>
      ) : (
        <form onSubmit={handleWithdraw}>
          <input
            type="number"
            placeholder="Amount (KSh)"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg mb-4"
            required
          />
          <textarea
            placeholder="Bank Details (Account Number, Bank Name)"
            value={bankDetails}
            onChange={(e) => setBankDetails(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg mb-4 h-24"
            required
          />
          <button
            type="submit"
            className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white py-3 rounded-lg font-semibold hover:shadow-lg transition"
          >
            Request Withdrawal
          </button>
        </form>
      )}
    </div>
  );
};
