import React from 'react';

interface LandingPageProps {
  onLogin: () => void;
  onSignup: () => void;
}

const heroImage = "https://d64gsuwffb70l.cloudfront.net/690ca0f7fd444ac0afe88667_1762435382951_dcd6fa4d.webp";

export const LandingPage: React.FC<LandingPageProps> = ({ onLogin, onSignup }) => {
  return (
    <div className="min-h-screen">
      <nav className="bg-white shadow-md py-4 px-6 flex justify-between items-center">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
          Swapversend
        </h1>
        <div className="flex gap-4">
          <button onClick={onLogin} className="px-6 py-2 text-purple-600 font-semibold hover:bg-purple-50 rounded-lg transition">
            Login
          </button>
          <button onClick={onSignup} className="px-6 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white font-semibold rounded-lg hover:shadow-lg transition">
            Sign Up
          </button>
        </div>
      </nav>

      <div className="relative h-screen flex items-center justify-center" style={{ backgroundImage: `url(${heroImage})`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
        <div className="absolute inset-0 bg-gradient-to-r from-purple-900 to-blue-900 opacity-80"></div>
        <div className="relative z-10 text-center text-white px-6">
          <h2 className="text-5xl md:text-7xl font-bold mb-6">Drive Your Wealth Forward</h2>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
            Invest in premium car rentals and earn daily returns up to KSh 600. Start your journey to financial freedom today.
          </p>
          <div className="flex gap-4 justify-center">
            <button onClick={onSignup} className="px-8 py-4 bg-white text-purple-600 font-bold rounded-lg text-lg hover:shadow-2xl transition">
              Get Started
            </button>
            <button onClick={onLogin} className="px-8 py-4 bg-transparent border-2 border-white text-white font-bold rounded-lg text-lg hover:bg-white hover:text-purple-600 transition">
              Login
            </button>
          </div>
        </div>
      </div>

      <div className="py-20 px-6 bg-gray-50">
        <div className="max-w-6xl mx-auto text-center">
          <h3 className="text-4xl font-bold text-gray-800 mb-12">Why Choose Swapversend?</h3>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-2xl shadow-lg">
              <div className="text-5xl mb-4">💰</div>
              <h4 className="text-2xl font-bold mb-3">High Returns</h4>
              <p className="text-gray-600">Earn up to 90% ROI in 30 days with our premium investment plans</p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-lg">
              <div className="text-5xl mb-4">🔒</div>
              <h4 className="text-2xl font-bold mb-3">Secure Platform</h4>
              <p className="text-gray-600">Bank-level security with encrypted transactions and data protection</p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-lg">
              <div className="text-5xl mb-4">👥</div>
              <h4 className="text-2xl font-bold mb-3">Referral Rewards</h4>
              <p className="text-gray-600">Earn 20% commission on Level 1 and 3% on Level 2 referrals</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
