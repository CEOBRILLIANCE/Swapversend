import React, { useState } from 'react';
import { AuthProvider, useAuth } from '../contexts/AuthContext';
import { LandingPage } from './LandingPage';
import { DashboardPage } from './DashboardPage';
import { LoginModal } from './LoginModal';
import { SignupModal } from './SignupModal';

const AppContent: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const [showLogin, setShowLogin] = useState(false);
  const [showSignup, setShowSignup] = useState(false);

  if (isAuthenticated) {
    return <DashboardPage />;
  }

  return (
    <>
      <LandingPage
        onLogin={() => setShowLogin(true)}
        onSignup={() => setShowSignup(true)}
      />
      <LoginModal
        isOpen={showLogin}
        onClose={() => setShowLogin(false)}
        onSwitchToSignup={() => {
          setShowLogin(false);
          setShowSignup(true);
        }}
      />
      <SignupModal
        isOpen={showSignup}
        onClose={() => setShowSignup(false)}
        onSwitchToLogin={() => {
          setShowSignup(false);
          setShowLogin(true);
        }}
      />
    </>
  );
};

export const SwapversendApp: React.FC = () => {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
};
