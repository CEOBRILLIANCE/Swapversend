import React from 'react';

interface Investment {
  id: number;
  level: string;
  amount: number;
  dailyReturn: number;
  daysRemaining: number;
  totalDays: number;
  carImage: string;
  color: string;
}

interface ActiveInvestmentsProps {
  investments: Investment[];
}

export const ActiveInvestments: React.FC<ActiveInvestmentsProps> = ({ investments }) => {
  if (investments.length === 0) {
    return (
      <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
        <p className="text-gray-500 text-lg">No active investments yet. Start by hiring a car!</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {investments.map((inv) => {
        const progress = ((inv.totalDays - inv.daysRemaining) / inv.totalDays) * 100;
        return (
          <div key={inv.id} className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition">
            <div className="flex items-center gap-6">
              <img src={inv.carImage} alt={inv.level} className="w-24 h-24 object-contain" />
              <div className="flex-1">
                <h3 className="text-xl font-bold text-gray-800 mb-2">{inv.level}</h3>
                <div className="grid grid-cols-2 gap-4 mb-3">
                  <div>
                    <p className="text-sm text-gray-600">Investment</p>
                    <p className="font-bold text-gray-800">KSh {inv.amount.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Daily Return</p>
                    <p className="font-bold" style={{ color: inv.color }}>KSh {inv.dailyReturn.toLocaleString()}</p>
                  </div>
                </div>
                <div className="mb-2">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Progress</span>
                    <span className="font-semibold">{inv.daysRemaining} days remaining</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div
                      className="h-3 rounded-full transition-all"
                      style={{ width: `${progress}%`, backgroundColor: inv.color }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
