import React from 'react';

interface StatCardProps {
  title: string;
  value: string;
  color: string;
  icon: string;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, color, icon }) => (
  <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-gray-600 text-sm mb-1">{title}</p>
        <p className={`text-3xl font-bold ${color}`}>{value}</p>
      </div>
      <div className={`text-4xl ${color}`}>{icon}</div>
    </div>
  </div>
);

interface DashboardStatsProps {
  activeInvestments: number;
  dailyEarnings: number;
  totalEarnings: number;
  referralEarnings: number;
}

export const DashboardStats: React.FC<DashboardStatsProps> = ({
  activeInvestments,
  dailyEarnings,
  totalEarnings,
  referralEarnings
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <StatCard title="Active Investments" value={activeInvestments.toString()} color="text-blue-600" icon="🚗" />
      <StatCard title="Daily Earnings" value={`KSh ${dailyEarnings.toLocaleString()}`} color="text-green-600" icon="💰" />
      <StatCard title="Total Earnings" value={`KSh ${totalEarnings.toLocaleString()}`} color="text-purple-600" icon="📈" />
      <StatCard title="Referral Earnings" value={`KSh ${referralEarnings.toLocaleString()}`} color="text-amber-600" icon="👥" />
    </div>
  );
};
