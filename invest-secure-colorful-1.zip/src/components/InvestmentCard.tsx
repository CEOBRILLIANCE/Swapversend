import React from 'react';
import { InvestmentPlan } from '../data/investmentPlans';

interface InvestmentCardProps {
  plan: InvestmentPlan;
  onHire: (plan: InvestmentPlan) => void;
}

export const InvestmentCard: React.FC<InvestmentCardProps> = ({ plan, onHire }) => {
  const totalReturn = plan.dailyReturn * plan.duration;
  const roi = ((totalReturn - plan.investment) / plan.investment * 100).toFixed(0);

  return (
    <div className="bg-white rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
      <div className={`bg-gradient-to-r ${plan.bgGradient} p-6 text-white`}>
        <h3 className="text-2xl font-bold">{plan.level}</h3>
        <p className="text-sm opacity-90">Premium Investment</p>
      </div>
      <div className="p-6">
        <img src={plan.carImage} alt={plan.level} className="w-full h-48 object-contain mb-4" />
        <div className="space-y-3 mb-6">
          <div className="flex justify-between">
            <span className="text-gray-600">Investment:</span>
            <span className="font-bold text-gray-800">KSh {plan.investment.toLocaleString()}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Daily Return:</span>
            <span className="font-bold" style={{ color: plan.color }}>KSh {plan.dailyReturn.toLocaleString()}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Duration:</span>
            <span className="font-bold text-gray-800">{plan.duration} days</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Total Return:</span>
            <span className="font-bold text-green-600">KSh {totalReturn.toLocaleString()}</span>
          </div>
          <div className="bg-gradient-to-r from-green-100 to-emerald-100 p-3 rounded-lg">
            <p className="text-center text-green-800 font-bold">ROI: {roi}%</p>
          </div>
        </div>
        <button
          onClick={() => onHire(plan)}
          className={`w-full bg-gradient-to-r ${plan.bgGradient} text-white py-3 rounded-lg font-semibold hover:shadow-lg transition-all`}
        >
          Hire & Earn Now
        </button>
      </div>
    </div>
  );
};
