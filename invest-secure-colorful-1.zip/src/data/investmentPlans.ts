export interface InvestmentPlan {
  id: number;
  level: string;
  investment: number;
  dailyReturn: number;
  duration: number;
  color: string;
  bgGradient: string;
  carImage: string;
}

export const investmentPlans: InvestmentPlan[] = [
  {
    id: 1,
    level: "Level 1",
    investment: 500,
    dailyReturn: 150,
    duration: 30,
    color: "#10B981",
    bgGradient: "from-emerald-500 to-emerald-600",
    carImage: "https://d64gsuwffb70l.cloudfront.net/690ca0f7fd444ac0afe88667_1762435379673_a742be4a.webp"
  },
  {
    id: 2,
    level: "Level 2",
    investment: 1200,
    dailyReturn: 360,
    duration: 30,
    color: "#3B82F6",
    bgGradient: "from-blue-500 to-blue-600",
    carImage: "https://d64gsuwffb70l.cloudfront.net/690ca0f7fd444ac0afe88667_1762435380522_55bb5f8d.webp"
  },
  {
    id: 3,
    level: "Level 3",
    investment: 1500,
    dailyReturn: 450,
    duration: 30,
    color: "#F59E0B",
    bgGradient: "from-amber-500 to-amber-600",
    carImage: "https://d64gsuwffb70l.cloudfront.net/690ca0f7fd444ac0afe88667_1762435381395_b719ac74.webp"
  },
  {
    id: 4,
    level: "Level 4",
    investment: 2000,
    dailyReturn: 600,
    duration: 30,
    color: "#8B5CF6",
    bgGradient: "from-purple-500 to-purple-600",
    carImage: "https://d64gsuwffb70l.cloudfront.net/690ca0f7fd444ac0afe88667_1762435382188_46f7c7d3.webp"
  }
];
